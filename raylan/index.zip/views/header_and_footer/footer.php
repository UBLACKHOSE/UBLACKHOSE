

<footer class="pt-4" style="background: #3e4649; height: 40px">
</footer>


<!-- Latest compiled and minified JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>
<script>
    // $('#myModal').modal("toggle");

    $('#myModal').on('shown.bs.modal', function (event) {});
</script>


</body>
</html>