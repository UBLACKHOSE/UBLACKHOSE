<?php
echo '
<div class="container-fluid">
    <div class="row">
    <div id="baner-1" >
    
    </div>
    <div id="baner-2" class="">
        <div class="row ">
        <div class="col-sm-9 offset-sm-3">
            <img style="float: left; width: 35px;" " src="/template/icons/camera-video.svg" >
            <h2 style="">
                Добавляй фильмы в библиотеку
            </h2>
         </div>
        </div>
        <div class="row" >
                <div class="col-sm-9 offset-sm-3">
            <img style="float: left; width: 35px;" src="/template/icons/play.svg" >
            <h2 style="margin-left: 5px">
                Более <strong>200000</strong> фильмов
            </h2>
            </div>
        </div>
        <div class="row" style="">
                <div class="col-sm-9 offset-sm-3">
            <img style="float: left; width: 35px" src="/template/icons/star.svg">
            <h2 style="margin-left: 5px">
                Ставь рейтинг фильмам
            </h2>
            </div>
        </div>
    </div>
    </div>
</div>';
