<?php
return array(
    'host' => 'localhost',
    'dbname'=> 'fsite_film',
    'user' => 'root',
    'password'=> '',
)
?>