<?php

return array(
    'user/login' => 'user/login',
    'user/register' => 'user/register',
    'user/logout' => 'user/logout',
    'cabinet' => 'cabinet/index',
    '' => 'site/index'


);

?>